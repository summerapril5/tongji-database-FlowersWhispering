namespace FlowersWhisperingAPI.Administrator.Models
{
    public class FeedbackDTO
    {
        public int UserId { get; set; } = 0;
        public string? FeedbackContent { get; set; } = null;
    }
}